import pickle
with open('end-part1_df.pkl', 'rb') as fp:
    df = pickle.load(fp)
	
	